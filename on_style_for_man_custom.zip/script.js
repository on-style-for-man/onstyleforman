
let carrinho = [];

function adicionarCarrinho(produto) {
    carrinho.push(produto);
    atualizarCarrinho();
}

function atualizarCarrinho() {
    let lista = document.getElementById("itens-carrinho");
    lista.innerHTML = "";
    carrinho.forEach(item => {
        let li = document.createElement("li");
        li.textContent = item;
        lista.appendChild(li);
    });
}

function finalizarCompra() {
    alert("Funcionalidade de checkout será ativada futuramente.");
}
